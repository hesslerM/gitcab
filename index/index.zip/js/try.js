$(function(){
	$(".content1 p#pan1").toggle(function(){
		$("#pan1 strong").text("折叠");
		$(this).next("div#panhide1").show();
		
	},function(){
		$("#pan1 strong").text("展开");
		$(this).next("div#panhide1").hide();
	})
})
$(function(){
	$(".content1 p#pan2").toggle(function(){
		$("#pan2 strong").text("折叠");
		$(this).next("div#panhide2").show();
	},function(){
		$("#pan2 strong").text("展开");
		$(this).next("div#panhide2").hide();
	})
})
$(function(){
	$(".content1 p#pan3").toggle(function(){
		$("#pan3 strong").text("折叠");
		$(this).next("div#panhide3").show();
	},function(){
		$("#pan3 strong").text("展开");
		$(this).next("div#panhide3").hide();
	})
})
$(function(){
	$(".content1 p#pan4").toggle(function(){
		$("#pan4 strong").text("折叠");
		$(this).next("div#panhide4").show();
	},function(){
		$("#pan4 strong").text("展开");
		$(this).next("div#panhide4").hide();
	})
})
$(function(){
	$(".content1 p#pan5").toggle(function(){
		$("#pan5 strong").text("折叠");
		$(this).next("div#panhide5").show();
	},function(){
		$("#pan5 strong").text("展开");
		$(this).next("div#panhide5").hide();
	})
})
$(function(){
	$("#logo").mouse
})
